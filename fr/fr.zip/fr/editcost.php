<?php
include 'includes/conn.php';
if (!isset($_SESSION['hotelsys'])) {
    header('Location:login.php');
}
$id=$_GET['id'];
?>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Modifier le coût | Hotel Manager</title>
<script src="ckeditor/ckeditor.js"></script>
  <script language="JavaScript" src="js/gen_validatorv4.js" type="text/javascript"></script>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">

    

    <link href="css/plugins/chosen/chosen.css" rel="stylesheet">

  

    <link href="css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">
    <link href="css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
   
    <link href="css/plugins/datapicker/datepicker3.css" rel="stylesheet">

    
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

</head>

<body>

    <div id="wrapper">

       <?php include 'nav.php'; ?>
        <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
        <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
                    </div>
            <ul class="nav navbar-top-links navbar-right">
             
                <li>
                    <a href="logout">
                        <i class="fa fa-sign-out"></i> Log out
                    </a>
                </li>
            </ul>

        </nav>
        </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Modifier les dépenses d'hôtel</h2>
                    <ol class="breadcrumb">
                         <li>              <a href=""><i class="fa fa-home"></i> Accueil</a>                    </li>
                        <li>
                            <a href="costs">Dépenses</a>
                        </li>
                        <li class="active">
                            <strong>Modifier les dépenses d'hôtel</strong>
                        </li>
                    </ol>
                </div>
             
            </div>
        <div class="wrapper wrapper-content animated fadeInRight">
                       <div class="row">

                <div class="col-lg-8">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            
                            <h5>Modifier les dépenses d'hôtel <small>Veillez Remplir tout les champs nécéssaires</small></h5>
                                                </div>
                        <div class="ibox-content">
                                               <?php
                         include_once 'includes/thumbs3.php';
if (isset($_POST['item'],$_POST['amount'],$_POST['date'])) {
    if ((empty($_POST['item']))||(empty($_POST['amount']))||(empty($_POST['date']))) {
        echo '  <div class="alert alert-danger"><i class="fa fa-warning"></i>
                                    Fill All Fields To Proceed</div>';
    } else {
        $item=  mysqli_real_escape_string($con, trim($_POST['item']));
        $amount=  mysqli_real_escape_string($con, trim($_POST['amount']));
        $date=  mysqli_real_escape_string($con, strtotime(str_replace('/', '-', $_POST['date'])));

        mysqli_query($con, "UPDATE costs SET cost_item='$item',amount='$amount',date='$date' WHERE cost_id='$id'")
         or die(mysqli_errno($con));

        echo '<div class="alert alert-success"><i class="fa fa-check"></i>Item Cost successfully Edited</div>';
    }
}
$costdetails= mysqli_query($con, "SELECT * FROM costs WHERE cost_id='$id'") or
 die(mysqli_errno($con));
$row=  mysqli_fetch_array($costdetails);
$cost_item2=$row['cost_item'];
$amount2=$row['amount'];
$date2=$row['date'];
?>
  <form method="post" class="form-horizontal" action=''  name="form" enctype="multipart/form-data">
                                <div class="form-group"><label class="col-sm-2 control-label">Article</label>

                                    <div class="col-sm-10"><input type="text"  value="<?php echo $cost_item2;?>" class="form-control" name='item' placeholder="Enter item" required='required'></div>
                                </div>
        <div class="form-group"><label class="col-sm-2 control-label">Montant</label>

                                    <div class="col-sm-10">   <div class="input-group">
                                            <span class="input-group-addon">shs</span>
                                            <input type="text" class="form-control" name="amount" 
                                            value="<?php echo $amount2;?>" required="required">
                                </div></div>
                                </div>
                            <div class="form-group" id="data_1">
                              <label class="col-sm-2 control-label">Date</label>
                               <div class="col-sm-10">
                                <div class="input-group date">
                                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                    <input type="text" class="form-control"
                                     name="date" value="<?php echo date('m/d/Y', $date2);?>">
                                </div>
                                </div>
                            </div>
                            <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                  <button class="btn btn-primary" name="submit" type="submit">Modifier le coût</button>
                                    </div>
                                </div>
                            </form>                                             

                    </div>                  
                </div>             
                    </div>                       


    </div>

    <!-- Mainly scripts -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="js/inspinia.js"></script>
    <script src="js/plugins/pace/pace.min.js"></script>

    <!-- Chosen -->
    <script src="js/plugins/chosen/chosen.jquery.js"></script>

   <!-- Input Mask-->
    <!--<script src="js/plugins/jasny/jasny-bootstrap.min.js"></script>-->

   <!-- Data picker -->
   <script src="js/plugins/datapicker/bootstrap-datepicker.js"></script>

  <script src="js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="js/plugins/dataTables/dataTables.bootstrap.js"></script>
    <!-- iCheck -->
    <!--<script src="js/plugins/iCheck/icheck.min.js"></script>-->

    <!-- MENU -->
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
 <script>
        $(document).ready(function(){

            $('#data_1 .input-group.date').datepicker({
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true,
                format: "dd/mm/yyyy",
            });
              $('.dataTables-example').dataTable();

            /* Init DataTables */
            var oTable = $('#editable').dataTable();

            /* Apply the jEditable handlers to the table */
            oTable.$('td').editable( 'http://webapplayers.com/example_ajax.php', {
                "callback": function( sValue, y ) {
                    var aPos = oTable.fnGetPosition( this );
                    oTable.fnUpdate( sValue, aPos[0], aPos[1] );
                },
                "submitdata": function ( value, settings ) {
                    return {
                        "row_id": this.parentNode.getAttribute('id'),
                        "column": oTable.fnGetPosition( this )[2]
                    };
                },

                "width": "90%"
            } );
            });
   </script>
 
</body>


</html>
